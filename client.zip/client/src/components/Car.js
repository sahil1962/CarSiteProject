import React, { useState } from 'react'
import { Modal } from "react-bootstrap"
export default function Car({ car }) {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
        <div style={{ margin: '70px' }} class="shadow-lg p-3 mb-5 bg-white rounded">

            <div onClick={handleShow}>
                <img src={car.image} class="img-fluid" style={{ height: '200px', width: '300px' }} />
            </div>

            <div class='flex-container'>
                <div class='w-100 m-1'>
                    <p>{car.name}</p>
                </div>
            </div>
            <div class='flex-container'>
                <div class='w-100 m-1'>
                    <p>Model - {car.year}</p>
                </div>

            </div>
            <div class='flex-container'>

                <div class='w-100'>
                    <p> PKR -  {car.prices}</p>
                </div>

                <div class='w-100'>
                    <p>mileage - {car.Mileage} </p>
                </div>

            </div>

            <div class='flex-container'>
                <div class="w-100 m-1">
                    <button class="btn">Add to cart</button>
                </div>
            </div>
            <Modal show={show} onHide={handleClose} >
                <Modal.Header closeButton>
                    <Modal.Title>{car.year} - {car.name}</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <img src={car.image} class="img-fluid" style={{ height: '300px', width: '500px' }} />
                    <p>Modal body text goes here.</p>
                </Modal.Body>

                <Modal.Footer>
                    <button class="btn" onClick={handleClose}>Close</button>
                </Modal.Footer>
            </Modal>
        </div>

    );
}