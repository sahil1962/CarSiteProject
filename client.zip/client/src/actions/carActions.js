// CURD operations for cars
import axios from "axios";
export const getAllCars=()=>dispatch=>{
    dispatch({type:"GET_CARS_REQUEST"})
    try {
        const response = axios.get("/api/cars/getcars")
        console.log(response);
        dispatch({type:"GET_CARS_SUCCESS", payload : response.data})

    } catch (error) {
        dispatch({type:"GET_CARS_FAILED", payload : error})
    }
}