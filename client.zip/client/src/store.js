import {combineReducers} from "redux";
import {createStore, applyMiddleware} from "redux";
import thunk from "redux-thunk";
import {getAllCarsReducer} from "./reducers/carReducers"
import { composeWithDevTools } from "redux-devtools-extension";




const finalReducer = combineReducers({
    getAllCarsReducer : getAllCarsReducer
})
 

const initialState = {}
const composeEnhancers =  composeWithDevTools({})
const store = createStore(finalReducer, initialState, composeEnhancers(applyMiddleware(thunk)))

export default store