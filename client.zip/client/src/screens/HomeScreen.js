import React from 'react'
import Car from "../components/Car"
import cars from "../cardata"
export default function HomeScreen() {
    return (
        <div>
            <div class="row">
                {cars.map(car => {
                    return <div class="col-md-4">
                        <div>
                            <Car car={car} />
                        </div>
                    </div>
                })}
            </div>
        </div>
    )
}
