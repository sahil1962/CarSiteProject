const cars = [{
        "year": "2022",
        "name": "Honda Civic",
        "varients": ["small", "medium", "large"],
        "prices": "200000",
        "Mileage": "1000",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftsacramento/2hgfc2f7xgh501986/20220224093806.NO3XP58R/closeups/cu-1.jpg"
    },
    {
        "year": "2020",
        "name": "Toyota Corolla Hybrid LE",
        "varients": ["small", "medium", "large"],
        "prices": "2595000",
        "Mileage": "15000",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftsandiego/jtdebrbe4lj019873/20220314192813.0VLXJJMB/closeups/cu-0.jpg"
    },
    {
        "year": "2018",
        "name": "Hyundai Elantra SEL",
        "prices": "25,950,00",
        "Mileage": "56000",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftseattle/5npd84lf3jh306356/20220110052201.WBB46JTI/closeups/cu-0.jpg"
    },
    {
        "year": "2015",
        "name": "Mazda 6 i Touring",
        "varients": ["small", "medium", "large"],
        "prices": "19950",
        "Mileage": "39000",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftlasvegas/jm1gj1v5xf1185571/20220213145728.DZV15TFM/closeups/cu-0.jpg"
    },
    {
        "year": "2017",
        "name": "BMW M4",
        "varients": ["small", "medium", "large"],
        "prices": "56950",
        "Mileage": "29000",
        "image": "https://shiftcars1.imgix.net/content/con1N4YbBmU7rzh6q5HJUWD8XJbWdsCD9DRVFOynoTQm254bmEbl4p?fit=max&w=745&auto=format%2Ccompress",
    },
    {
        "year": "2015",
        "name": "Dodge Challenger SXT",
        "varients": ["small", "medium", "large"],
        "prices": "23300",
        "Mileage": "32200",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftsanantonio/2c3cdzag3fh723982/20211028100559.8UTKCX1Y/closeups/cu-0.jpg"
    },
    {
        "year": "2015",
        "name": "Ford F-150 Lariat",
        "varients": ["small", "medium", "large"],
        "prices": "36950",
        "Mileage": "49500",
        "image": "https://shiftcars1.imgix.net/content/con13jSoPZgBgUXGDYKtdjJXDcIhp86J6NXbfyZIwemuj1jWIrENDy?fit=max&w=745&auto=format%2Ccompress",
    },
    {
        "year": "2020",
        "name": "Tesla Model 3 Standard Range Plus",
        "varients": ["small", "medium", "large"],
        "prices": "42500",
        "Mileage": "36300",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftlasvegas/5yj3e1ea1lf741172/20220303145913.MRJFNRMA/closeups/cu-0.jpg"
    },
    {
        "year": "2017",
        "name": "Jeep Cherokee Latitude",
        "varients": ["small", "medium", "large"],
        "prices": "19950",
        "Mileage": "58000",
        "image": "https://cdn.spincar.com/swipetospin-viewers/shiftlasvegas/1c4pjlcb2hw662052/20220222141711.JHPTF9JG/closeups/cu-0.jpg"
    },
    {
        "year": "2019",
        "name": "Subaru Outback Premium",
        "varients": ["small", "medium", "large"],
        "prices": "26950",
        "Mileage": "29200",
        "image": "https://shiftcars1.imgix.net/content/con1QvUNBOBWER4lmBqINLr1U1uO9wGqn2iEZHt50wpKbLhkcIszH3?fit=max&w=745&auto=format%2Ccompress",
    }
]
export default cars