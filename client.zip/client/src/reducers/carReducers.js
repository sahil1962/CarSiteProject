export const getAllCarsReducer=(state = {}, action)=>{
    switch (action.type ) {
        case "GET_CARS_REQUEST": return{
            ...state
        }
        case "GET_CARS_SUCCESS" : return{
            cars : action.payload
        }
        case "GET_CARS_FAILED" : return{
            error:action.payload
        }
        default: return state
    }
}